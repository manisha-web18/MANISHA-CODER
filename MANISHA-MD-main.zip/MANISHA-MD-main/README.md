<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">
<img src="https://files.catbox.moe/uo5syg.gif" alt="Loading..." width="520"/>
<p align="center">
  
<p align="center">
  <h1 align="center">🌀MANISHA-MD 1.0🌀</h1>
</p>

**`Updated` The Version 1.0**


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.herokuapp.com?font=Ribeye&size=50&pause=1000&color=FF00FF&center=true&width=910&height=100&lines=MANISHA-MD;ᴍᴜʟᴛɪ+ᴅᴇᴠɪᴄᴇ+ᴡʜᴀᴛꜱᴀᴘᴘ+ʙᴏᴛ;ᴄʀᴇᴀᴛᴇᴅ+ʙʏ+ᴍᴀɴɪꜱʜᴀ+ᴄᴏᴅᴇʀ" alt="Typing SVG" />
  </a> 
</div> 



---
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<h1 align="center">
<a href="https://ibb.co/ccjyFW1Z"><img src="https://i.ibb.co/TBsw8Qk7/20250527-030737.png" alt="20250527-030737" border="0" /></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<h1 align="center"> ᴍᴀɴɪꜱʜᴀ-ᴍᴅ </h1> 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center">ᴍᴀɴɪꜱʜᴀ-ᴍᴅ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴍᴀɴɪꜱʜᴀ ᴄᴏᴅᴇʀ</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## `ᴡʜᴀᴛꜱᴀᴘᴘ ᴄʜᴀɴɴᴇʟ`
## [*𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗝𝗢𝗜𝗡*](https://whatsapp.com/channel/0029VbAdMtMGk1G1R9Yg2L3x)

## `ᴄᴏɴᴛᴀᴄᴛ ᴍᴀɴɪꜱʜᴀ-ᴍᴅ ᴏᴡɴᴇʀ`
## [`𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗠𝗘`](http://wa.me/+94721551183?text=HI+MANISHA-MD+I+NEED+YOUR+HELP😒)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## `ℹ️ NOTICE`
 NOT FOR SALE - IF ANY PLUGIN'S CODE IS OBFUSCATED, YOU DO NOT HAVE PERMISSION TO EDIT IT IN ANY FORM. PLEASE REMEMBER TO GIVE CREDIT IF YOU ARE USING OR RE-UPLOADING MY PLUGINS/FILES. WISHING YOU A WONDERFUL DAY AHEAD!</p>
  
---
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <br>
<h2 align="center"> ⚠️ DISCLAIMER ⚠️
 </h2>
 
 ---

<h3 align="center"> DON'T COPY MANISHA-MD SCRIPT WITHOUT PERMISSION OF MANISHA CODER
</h3>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</details>
<p align="center">
<img src="https://github.com/Platane/snk/raw/output/github-contribution-grid-snake.svg" alt="nz" width="700"/>
</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a> 

<p align="center">
<img src="https://files.catbox.moe/vxv1r3.gif" alt="Loading..." width="520"/>
<p align="center">

---
